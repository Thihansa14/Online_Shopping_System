public interface ShoppingManager {
    void addProduct();
    void printProducts();
    void deleteProduct();
    void saveProductsToFile();


}
